const express = require("express");
const router = express.Router();
const User = require("../model/user/user");
const Game = require("../model/game/game");
const Bet = require("../model/bet/bet");
const GameResult = require("../model/gameResult/gameResult");
const { setApiResponse } = require("../utils/setApiResponse");
const Payment = require("../model/payment/payment");

router.get("/stats", async (req, res) => {
  try {
    const [totalUsers, totalGames, totalBets, totalResults] = await Promise.all(
      [
        User.countDocuments(),
        Game.countDocuments(),
        Bet.countDocuments(),
        GameResult.countDocuments({ result: { $ne: null } }),
      ]
    );
    const [totalPaymentRequests, totalWithdrawRequests] = await Promise.all([
      // Payment requests (type: ADD)
      Payment.countDocuments({ type: "ADD", status: "pending" }),
      // Withdraw requests (type: WITHDRAWL)
      Payment.countDocuments({ type: "WITHDRAWL", status: "pending" }),
    ]);

    return setApiResponse(
      200,
      true,
      {
        totalUsers,
        totalGames,
        totalBets,
        totalResultsDeclared: totalResults,
        totalPaymentRequests,
        totalWithdrawRequests,
      },
      null,
      res
    );
  } catch (error) {
    return setApiResponse(500, false, null, error.message, res);
  }
});

module.exports = router;
