const GameResult = require("./gameResult");
const Game = require("../game/game");

// Get games with results and filter by name, startDate, endDate
const getGamesWithResults = async ({ name, startDate, endDate }) => {
  const gameFilter = {};
  if (name) {
    gameFilter.name = { $regex: `^${name}`, $options: "i" };
  }
  if (startDate || endDate) {
    gameFilter.createdAt = {};
    if (startDate) gameFilter.createdAt.$gte = new Date(startDate);
    if (endDate) gameFilter.createdAt.$lte = new Date(endDate);
  }

  // Find games with filter
  const games = await Game.find(gameFilter).lean();
  const gameIds = games.map(g => g._id);

  // Find results for these games
  const results = await GameResult.find({ game: { $in: gameIds } }).lean();
  const resultsMap = {};
  results.forEach(r => {
    resultsMap[r.game.toString()] = r;
  });

  // Attach result to each game
  return games.map(game => ({
    ...game,
    result: resultsMap[game._id.toString()] || null
  }));
};

module.exports = {
  getGamesWithResults,
};
